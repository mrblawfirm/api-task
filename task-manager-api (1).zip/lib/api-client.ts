// API client for frontend to interact with the Task Manager API

import type { Task, CreateTaskRequest, UpdateTaskRequest, TasksResponse, SearchParams } from "./types"

const API_BASE_URL = "/api"

export class TaskApiClient {
  // Get all tasks with optional filtering and pagination
  static async getTasks(params?: SearchParams): Promise<TasksResponse> {
    const searchParams = new URLSearchParams()

    if (params?.keyword) searchParams.append("keyword", params.keyword)
    if (params?.status) searchParams.append("status", params.status)
    if (params?.page) searchParams.append("page", params.page.toString())
    if (params?.limit) searchParams.append("limit", params.limit.toString())

    const response = await fetch(`${API_BASE_URL}/tasks?${searchParams}`)

    if (!response.ok) {
      throw new Error(`Failed to fetch tasks: ${response.statusText}`)
    }

    return response.json()
  }

  // Get a specific task by ID
  static async getTask(id: number): Promise<Task> {
    const response = await fetch(`${API_BASE_URL}/tasks/${id}`)

    if (!response.ok) {
      throw new Error(`Failed to fetch task: ${response.statusText}`)
    }

    return response.json()
  }

  // Create a new task
  static async createTask(data: CreateTaskRequest): Promise<Task> {
    const response = await fetch(`${API_BASE_URL}/tasks`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to create task")
    }

    return response.json()
  }

  // Update an existing task
  static async updateTask(id: number, data: UpdateTaskRequest): Promise<Task> {
    const response = await fetch(`${API_BASE_URL}/tasks/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to update task")
    }

    return response.json()
  }

  // Delete a task
  static async deleteTask(id: number): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/tasks/${id}`, {
      method: "DELETE",
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to delete task")
    }
  }

  // Search tasks with advanced parameters
  static async searchTasks(params: SearchParams): Promise<TasksResponse> {
    const searchParams = new URLSearchParams()

    if (params.keyword) searchParams.append("q", params.keyword)
    if (params.status) searchParams.append("status", params.status)
    if (params.page) searchParams.append("page", params.page.toString())
    if (params.limit) searchParams.append("limit", params.limit.toString())

    const response = await fetch(`${API_BASE_URL}/tasks/search?${searchParams}`)

    if (!response.ok) {
      throw new Error(`Failed to search tasks: ${response.statusText}`)
    }

    return response.json()
  }
}
