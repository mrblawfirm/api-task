// Type definitions for the Task Manager API

export interface Task {
  id: number
  title: string
  description: string
  status: "pending" | "in-progress" | "completed"
  created_at: string
  updated_at: string
}

export interface CreateTaskRequest {
  title: string
  description: string
  status?: "pending" | "in-progress" | "completed"
}

export interface UpdateTaskRequest {
  title?: string
  description?: string
  status?: "pending" | "in-progress" | "completed"
}

export interface TasksResponse {
  tasks: Task[]
  total: number
  page: number
  limit: number
}

export interface SearchParams {
  keyword?: string
  status?: "pending" | "in-progress" | "completed"
  page?: number
  limit?: number
}
