// Simple in-memory database for demo purposes
// In production, replace with actual database connection

import type { Task, CreateTaskRequest, UpdateTaskRequest } from "./types"

const tasks: Task[] = [
  {
    id: 1,
    title: "Setup project structure",
    description: "Initialize the Next.js project with required dependencies",
    status: "completed",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 2,
    title: "Create API endpoints",
    description: "Implement CRUD operations for task management",
    status: "in-progress",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 3,
    title: "Build user interface",
    description: "Design and implement the frontend components",
    status: "pending",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 4,
    title: "Add search functionality",
    description: "Implement keyword search across title and description",
    status: "pending",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 5,
    title: "Implement filtering",
    description: "Add status-based filtering for tasks",
    status: "pending",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

let nextId = 6

export class TaskDatabase {
  static getAllTasks(): Task[] {
    return tasks
  }

  static getTaskById(id: number): Task | undefined {
    return tasks.find((task) => task.id === id)
  }

  static createTask(data: CreateTaskRequest): Task {
    const newTask: Task = {
      id: nextId++,
      title: data.title,
      description: data.description,
      status: data.status || "pending",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    tasks.push(newTask)
    return newTask
  }

  static updateTask(id: number, data: UpdateTaskRequest): Task | null {
    const taskIndex = tasks.findIndex((task) => task.id === id)
    if (taskIndex === -1) return null

    const updatedTask = {
      ...tasks[taskIndex],
      ...data,
      updated_at: new Date().toISOString(),
    }
    tasks[taskIndex] = updatedTask
    return updatedTask
  }

  static deleteTask(id: number): boolean {
    const taskIndex = tasks.findIndex((task) => task.id === id)
    if (taskIndex === -1) return false

    tasks.splice(taskIndex, 1)
    return true
  }

  static searchTasks(keyword?: string, status?: string): Task[] {
    let filteredTasks = tasks

    // Filter by status
    if (status && ["pending", "in-progress", "completed"].includes(status)) {
      filteredTasks = filteredTasks.filter((task) => task.status === status)
    }

    // Search by keyword in title and description
    if (keyword) {
      const searchTerm = keyword.toLowerCase()
      filteredTasks = filteredTasks.filter(
        (task) => task.title.toLowerCase().includes(searchTerm) || task.description.toLowerCase().includes(searchTerm),
      )
    }

    return filteredTasks
  }
}
