-- Create tasks table for the Task Manager API
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in-progress', 'completed')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for better search performance
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_title ON tasks USING gin(to_tsvector('english', title));
CREATE INDEX IF NOT EXISTS idx_tasks_description ON tasks USING gin(to_tsvector('english', description));

-- Insert sample data
INSERT INTO tasks (title, description, status) VALUES
('Setup project structure', 'Initialize the Next.js project with required dependencies', 'completed'),
('Create API endpoints', 'Implement CRUD operations for task management', 'in-progress'),
('Build user interface', 'Design and implement the frontend components', 'pending'),
('Add search functionality', 'Implement keyword search across title and description', 'pending'),
('Implement filtering', 'Add status-based filtering for tasks', 'pending');
