"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Filter } from "lucide-react"
import { TaskCard } from "@/components/task-card"
import { TaskForm } from "@/components/task-form"
import type { Task, TasksResponse } from "@/lib/types"
import { TaskApiClient } from "@/lib/api-client"

export default function TaskManagerPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [searchKeyword, setSearchKeyword] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [showTaskForm, setShowTaskForm] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | undefined>()

  const fetchTasks = async () => {
    try {
      setLoading(true)
      const params = {
        ...(searchKeyword && { keyword: searchKeyword }),
        ...(statusFilter !== "all" && { status: statusFilter as Task["status"] }),
        limit: 50,
      }
      const response: TasksResponse = await TaskApiClient.getTasks(params)
      setTasks(response.tasks)
    } catch (error) {
      console.error("Failed to fetch tasks:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTasks()
  }, [searchKeyword, statusFilter])

  const handleEditTask = (task: Task) => {
    setEditingTask(task)
    setShowTaskForm(true)
  }

  const handleFormClose = () => {
    setShowTaskForm(false)
    setEditingTask(undefined)
  }

  const getTaskCounts = () => {
    return {
      total: tasks.length,
      pending: tasks.filter((t) => t.status === "pending").length,
      inProgress: tasks.filter((t) => t.status === "in-progress").length,
      completed: tasks.filter((t) => t.status === "completed").length,
    }
  }

  const counts = getTaskCounts()

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground text-balance">Task Manager</h1>
              <p className="text-muted-foreground mt-1">Organize and track your tasks efficiently</p>
            </div>
            <Button onClick={() => setShowTaskForm(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Task
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-card rounded-lg p-4 border">
              <div className="text-2xl font-bold text-card-foreground">{counts.total}</div>
              <div className="text-sm text-muted-foreground">Total Tasks</div>
            </div>
            <div className="bg-card rounded-lg p-4 border">
              <div className="text-2xl font-bold text-chart-3">{counts.pending}</div>
              <div className="text-sm text-muted-foreground">Pending</div>
            </div>
            <div className="bg-card rounded-lg p-4 border">
              <div className="text-2xl font-bold text-chart-2">{counts.inProgress}</div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </div>
            <div className="bg-card rounded-lg p-4 border">
              <div className="text-2xl font-bold text-chart-1">{counts.completed}</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tasks by title or description..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Task Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-muted-foreground">Loading tasks...</div>
          </div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-muted-foreground mb-4">
              {searchKeyword || statusFilter !== "all"
                ? "No tasks match your search criteria"
                : "No tasks yet. Create your first task to get started!"}
            </div>
            {!searchKeyword && statusFilter === "all" && (
              <Button onClick={() => setShowTaskForm(true)} variant="outline" className="gap-2">
                <Plus className="h-4 w-4" />
                Create First Task
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tasks.map((task) => (
              <TaskCard key={task.id} task={task} onUpdate={fetchTasks} onEdit={handleEditTask} />
            ))}
          </div>
        )}

        {/* Task Form Modal */}
        <TaskForm open={showTaskForm} onOpenChange={handleFormClose} task={editingTask} onSuccess={fetchTasks} />
      </div>
    </div>
  )
}
