import { type NextRequest, NextResponse } from "next/server"
import { TaskDatabase } from "@/lib/database"

// GET /api/tasks/search - Advanced search endpoint
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const keyword = searchParams.get("q") || searchParams.get("keyword") || undefined
    const status = searchParams.get("status") || undefined
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    // Validate status parameter
    if (status && !["pending", "in-progress", "completed"].includes(status)) {
      return NextResponse.json(
        { error: "Invalid status. Must be 'pending', 'in-progress', or 'completed'" },
        { status: 400 },
      )
    }

    // Get filtered tasks
    const filteredTasks = TaskDatabase.searchTasks(keyword, status)

    // Implement pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedTasks = filteredTasks.slice(startIndex, endIndex)

    return NextResponse.json({
      tasks: paginatedTasks,
      total: filteredTasks.length,
      page,
      limit,
      totalPages: Math.ceil(filteredTasks.length / limit),
      searchParams: {
        keyword,
        status,
      },
    })
  } catch (error) {
    console.error("Error searching tasks:", error)
    return NextResponse.json({ error: "Failed to search tasks" }, { status: 500 })
  }
}
