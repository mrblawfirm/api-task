import { type NextRequest, NextResponse } from "next/server"
import { TaskDatabase } from "@/lib/database"
import type { UpdateTaskRequest } from "@/lib/types"

// GET /api/tasks/[id] - Get a specific task
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid task ID" }, { status: 400 })
    }

    const task = TaskDatabase.getTaskById(id)

    if (!task) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 })
    }

    return NextResponse.json(task)
  } catch (error) {
    console.error("Error fetching task:", error)
    return NextResponse.json({ error: "Failed to fetch task" }, { status: 500 })
  }
}

// PUT /api/tasks/[id] - Update a specific task
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid task ID" }, { status: 400 })
    }

    const body: UpdateTaskRequest = await request.json()

    // Validate status if provided
    if (body.status && !["pending", "in-progress", "completed"].includes(body.status)) {
      return NextResponse.json(
        { error: "Invalid status. Must be 'pending', 'in-progress', or 'completed'" },
        { status: 400 },
      )
    }

    // Validate title if provided
    if (body.title !== undefined && body.title.trim() === "") {
      return NextResponse.json({ error: "Title cannot be empty" }, { status: 400 })
    }

    const updatedTask = TaskDatabase.updateTask(id, {
      ...(body.title !== undefined && { title: body.title.trim() }),
      ...(body.description !== undefined && { description: body.description.trim() }),
      ...(body.status && { status: body.status }),
    })

    if (!updatedTask) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 })
    }

    return NextResponse.json(updatedTask)
  } catch (error) {
    console.error("Error updating task:", error)
    return NextResponse.json({ error: "Failed to update task" }, { status: 500 })
  }
}

// DELETE /api/tasks/[id] - Delete a specific task
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid task ID" }, { status: 400 })
    }

    const deleted = TaskDatabase.deleteTask(id)

    if (!deleted) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Task deleted successfully" })
  } catch (error) {
    console.error("Error deleting task:", error)
    return NextResponse.json({ error: "Failed to delete task" }, { status: 500 })
  }
}
