import { type NextRequest, NextResponse } from "next/server"
import { TaskDatabase } from "@/lib/database"
import type { CreateTaskRequest } from "@/lib/types"

// GET /api/tasks - Get all tasks with optional search and filtering
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const keyword = searchParams.get("keyword") || undefined
    const status = searchParams.get("status") || undefined
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    // Get filtered tasks
    const filteredTasks = TaskDatabase.searchTasks(keyword, status)

    // Implement pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedTasks = filteredTasks.slice(startIndex, endIndex)

    return NextResponse.json({
      tasks: paginatedTasks,
      total: filteredTasks.length,
      page,
      limit,
      totalPages: Math.ceil(filteredTasks.length / limit),
    })
  } catch (error) {
    console.error("Error fetching tasks:", error)
    return NextResponse.json({ error: "Failed to fetch tasks" }, { status: 500 })
  }
}

// POST /api/tasks - Create a new task
export async function POST(request: NextRequest) {
  try {
    const body: CreateTaskRequest = await request.json()

    // Validate required fields
    if (!body.title || body.title.trim() === "") {
      return NextResponse.json({ error: "Title is required" }, { status: 400 })
    }

    // Validate status if provided
    if (body.status && !["pending", "in-progress", "completed"].includes(body.status)) {
      return NextResponse.json(
        { error: "Invalid status. Must be 'pending', 'in-progress', or 'completed'" },
        { status: 400 },
      )
    }

    const newTask = TaskDatabase.createTask({
      title: body.title.trim(),
      description: body.description?.trim() || "",
      status: body.status || "pending",
    })

    return NextResponse.json(newTask, { status: 201 })
  } catch (error) {
    console.error("Error creating task:", error)
    return NextResponse.json({ error: "Failed to create task" }, { status: 500 })
  }
}
