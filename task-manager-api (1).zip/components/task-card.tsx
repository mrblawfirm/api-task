"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { MoreHorizontal, Edit, Trash2, Clock, CheckCircle, Circle } from "lucide-react"
import type { Task } from "@/lib/types"
import { TaskApiClient } from "@/lib/api-client"

interface TaskCardProps {
  task: Task
  onUpdate: () => void
  onEdit: (task: Task) => void
}

const statusConfig = {
  pending: {
    label: "Pending",
    color: "bg-chart-3 text-white",
    icon: Circle,
  },
  "in-progress": {
    label: "In Progress",
    color: "bg-chart-2 text-white",
    icon: Clock,
  },
  completed: {
    label: "Completed",
    color: "bg-chart-1 text-white",
    icon: CheckCircle,
  },
}

export function TaskCard({ task, onUpdate, onEdit }: TaskCardProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)

  const config = statusConfig[task.status]
  const StatusIcon = config.icon

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await TaskApiClient.deleteTask(task.id)
      onUpdate()
    } catch (error) {
      console.error("Failed to delete task:", error)
    } finally {
      setIsDeleting(false)
      setShowDeleteDialog(false)
    }
  }

  const handleStatusChange = async (newStatus: Task["status"]) => {
    try {
      await TaskApiClient.updateTask(task.id, { status: newStatus })
      onUpdate()
    } catch (error) {
      console.error("Failed to update task status:", error)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  return (
    <>
      <Card className="group hover:shadow-md transition-shadow duration-200">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0 flex-1">
              <StatusIcon className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <h3 className="font-semibold text-card-foreground text-balance leading-tight">{task.title}</h3>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreHorizontal className="h-4 w-4" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(task)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setShowDeleteDialog(true)} className="text-destructive">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            {task.description && (
              <p className="text-sm text-muted-foreground text-pretty leading-relaxed">{task.description}</p>
            )}

            <div className="flex items-center justify-between">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-7 bg-transparent">
                    <Badge className={`${config.color} mr-2 h-5 px-2`}>{config.label}</Badge>
                    Change Status
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {Object.entries(statusConfig).map(([status, statusConf]) => (
                    <DropdownMenuItem
                      key={status}
                      onClick={() => handleStatusChange(status as Task["status"])}
                      disabled={status === task.status}
                    >
                      <statusConf.icon className="h-4 w-4 mr-2" />
                      {statusConf.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <span className="text-xs text-muted-foreground">{formatDate(task.updated_at)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Task</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{task.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
